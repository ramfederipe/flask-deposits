import os
import time
import datetime
import pandas as pd
import numpy as np
from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from models import Base, Deposit  # make sure Deposit model has "deleted = Column(Boolean, default=False)"
from flask import Flask





# --- Flask setup ---
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


def format_header(name):
    # special cases
    special = {
         "id": "ID",
        "deposit_type": "Deposit Type",
        "merchant_code": "Merchant Code",
        "customer": "Customer",
        "txnid": "TXNID",
        "currency": "Currency",
        "bank": "Bank",
        "from_account": "From Account",
        "to_account": "To Account",
        "amount": "Amount",
        "original_amount": "Original Amount",
        "rebalance": "Rebalance",
        "fee": "Fee",
        "created_time": "Created Time",
        "updated_time": "Updated Time",
        "transfer_time": "Transfer Time",
        "status": "Status",
        "audit": "Audit",
        "note_message": "Note Message",
        "refcode": "RefCode",
        "approve_by": "Approve By",
        "matched_by": "Matched By",
        "confirm_by": "Confirm By",  # fixed typo
        "last_updated": "Last Updated"

    }
    if name in special:
        return special[name]

    # general formatting: replace "_" with space and capitalize
    return name.replace("_", " ").title()



# --- Database setup ---
engine = create_engine('sqlite:///deposits.db')
Session = sessionmaker(bind=engine)
session = Session()

def df_to_html_with_class(df):
    html = '<table class="excel-table"><thead><tr>'
    for col in df.columns:
        if col != 'row_class':
            html += f'<th>{col}</th>'
    html += '<th>Action</th></tr></thead><tbody>'

    for _, row in df.iterrows():
        row_class = row.get('row_class', '')
        html += f'<tr class="{row_class}">'
        for col in df.columns:
            if col != 'row_class':
                cell_value = '' if row[col] is None else row[col]  # ✅ blank if None
                html += f'<td>{cell_value}</td>'
        html += f'''
        <td>
            <form method="POST" action="{url_for('delete_deposit', id=row['ID'])}">
                <button type="submit" class="delete-btn">Delete</button>
            </form>
        </td>
        '''
        html += '</tr>'
    html += '</tbody></table>'
    return html

#For filter and search
def get_filtered_deposits(params):
    query = session.query(Deposit).filter(Deposit.deleted == False)

    # 🔍 Search across multiple text fields
    if params.get("search"):
        search_term = f"%{params['search']}%"
        query = query.filter(
            (Deposit.txnid.ilike(search_term)) |
            (Deposit.refcode.ilike(search_term)) |
            (Deposit.customer.ilike(search_term))
        )

    # 🎯 Apply filters
    if params.get("status"):
        query = query.filter(Deposit.status == params["status"])
    if params.get("merchant_code"):
        query = query.filter(Deposit.merchant_code == params["merchant_code"])
    if params.get("bank"):
        query = query.filter(Deposit.bank == params["bank"])
    if params.get("deposit_type"):
        query = query.filter(Deposit.deposit_type == params["deposit_type"])

    return query.all()




@app.route('/deposit', methods=['GET', 'POST'])
def deposit():
    table_html = ""
    if request.method == 'POST':
        # Handle uploaded Excel
        file = request.files.get('excel_file')
        if file and file.filename:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Read Excel into DataFrame
            df = pd.read_excel(filepath, engine='openpyxl')
            df = df.replace({np.nan: ''})

            # Insert into DB
            for _, row in df.iterrows():
                deposit_row = Deposit(
                    deposit_type=row.get('Deposit Type', ''),
                    merchant_code=row.get('Merchant Code', ''),
                    txnid=row.get('TXNID', ''),
                    customer=row.get('Customer', ''),
                    currency=row.get('Currency', ''),
                    bank=row.get('Bank', ''),
                    from_account=row.get('From Account', ''),
                    to_account=row.get('To Account', ''),
                    amount=float(row.get('Amount') or 0),
                    original_amount=float(row.get('Original Amount') or 0),
                    rebalance=float(row.get('ReBalance') or 0),
                    fee=float(row.get('Fee') or 0),
                    created_time=row.get('Created Time') or datetime.datetime.utcnow(),
                    updated_time=row.get('Updated Time'),
                    transfer_time=row.get('Transfer Time'),
                    status=row.get('Status', ''),
                    audit=row.get('Audit', ''),
                    note_message=row.get('Note Message', ''),
                    refcode=row.get('RefCode', ''),
                    approve_by=row.get('Approve By', ''),
                    matched_by=row.get('Matched By', ''),
                    confirm_by=row.get('Confirm By', ''),
                    last_updated=datetime.datetime.utcnow(),
                    deleted=False
                )
                session.add(deposit_row)
            session.commit()

        # After upload, use **params** even if empty
        params = {
            "search": request.form.get("search", "").strip(),
            "status": request.form.get("status", "").strip(),
            "merchant_code": request.form.get("merchant_code", "").strip(),
            "bank": request.form.get("bank", "").strip(),
            "deposit_type": request.form.get("deposit_type", "").strip()
        }
        # Remove empty filters
        params = {k: v for k, v in params.items() if v}

        # ✅ Call filtered deposits safely
        deposits = get_filtered_deposits(params)

    else:  # GET request
        params = {
            "search": request.args.get("search", "").strip(),
            "status": request.args.get("status", "").strip(),
            "merchant_code": request.args.get("merchant_code", "").strip(),
            "bank": request.args.get("bank", "").strip(),
            "deposit_type": request.args.get("deposit_type", "").strip()
        }
        params = {k: v for k, v in params.items() if v}
        deposits = get_filtered_deposits(params)

    # Build table HTML
    columns = [c.name for c in Deposit.__table__.columns if c.name != "deleted"]
    table_html = '<table id="depositTable" class="excel-table"><thead><tr>'
    for col in columns:
        table_html += f"<th>{format_header(col)}</th>"
    table_html += "<th>Actions</th></tr></thead><tbody>"

    for d in deposits:
        table_html += "<tr>"
        for col in columns:
            table_html += f"<td>{getattr(d, col) if getattr(d, col) is not None else ''}</td>"
        table_html += f"<td><a href='{url_for('delete_deposit', deposit_id=d.id)}'>Delete</a></td>"
        table_html += "</tr>"
    table_html += "</tbody></table>"

    # Dropdown options
    merchant_codes = [m[0] for m in session.query(Deposit.merchant_code).distinct().all() if m[0]]
    banks = [b[0] for b in session.query(Deposit.bank).distinct().all() if b[0]]
    statuses = [s[0] for s in session.query(Deposit.status).distinct().all() if s[0]]
    deposit_types = [d[0] for d in session.query(Deposit.deposit_type).distinct().all() if d[0]]

    return render_template(
        "deposit.html",
        table_html=table_html,
        params=params,
        merchant_codes=merchant_codes,
        banks=banks,
        statuses=statuses,
        deposit_types=deposit_types,
        columns=columns,
        format_header=format_header
    )



# ---------- DELETE DEPOSIT ----------
@app.route('/deposit/delete/<int:deposit_id>')
def delete_deposit(deposit_id):
    deposit = session.query(Deposit).get(deposit_id)
    if deposit:
        deposit.deleted = True
        session.commit()
    return redirect(url_for('deposit'))


# ---------- DEPOSIT BIN ----------
@app.route('/deposit/bin')
def deposit_bin():
    deposits = session.query(Deposit).filter_by(deleted=True).all()
    table_html = ""
    if deposits:
        columns = [c.name for c in Deposit.__table__.columns if c.name not in ["deleted"]]
        table_html += "<table border=1><tr>"
        for col in columns:
            table_html += f"<th>{col}</th>"
        table_html += "<th>Actions</th></tr>"

        for d in deposits:
            table_html += "<tr>"
            for col in columns:
                table_html += f"<td>{getattr(d, col)}</td>"
            table_html += f"""
                <td>
                    <a href='{url_for('restore_deposit', deposit_id=d.id)}'>Restore</a> |
                    <a href='{url_for('permanent_delete', deposit_id=d.id)}'>Delete Permanently</a>
                </td>
            """
            table_html += "</tr>"
        table_html += "</table>"

    return render_template("deposit_bin.html", table_html=table_html)


@app.route('/deposit/restore/<int:deposit_id>')
def restore_deposit(deposit_id):
    deposit = session.query(Deposit).get(deposit_id)
    if deposit:
        deposit.deleted = False
        session.commit()
    return redirect(url_for('deposit_bin'))


@app.route('/deposit/permanent_delete/<int:deposit_id>')
def permanent_delete(deposit_id):
    deposit = session.query(Deposit).get(deposit_id)
    if deposit:
        session.delete(deposit)
        session.commit()
    return redirect(url_for('deposit_bin'))



# --- Withdrawal Upload ---
@app.route('/withdrawal', methods=['GET', 'POST'])
def withdrawal():
    table_html = ''
    if request.method == 'POST':
        file = request.files.get('excel_file')
        if file:
            filename = secure_filename(file.filename)
            unique_filename = f"{int(time.time())}_{filename}"
            filepath = os.path.join('uploads', unique_filename)
            file.save(filepath)

            df = pd.read_excel(filepath, engine='openpyxl')
            df = df.replace({np.nan: ''})

            def balance_class(val):
                if val == 0 or val == '' or val is None:
                    return 'grey'
                elif val < 500:
                    return 'low'
                elif val < 2000:
                    return 'medium'
                else:
                    return 'high'

            if 'Balance' in df.columns:
                df['row_class'] = df['Balance'].apply(balance_class)
            else:
                df['row_class'] = ''

            table_html = df.to_html(classes='excel-table', index=False, escape=False)

    return render_template('withdrawal.html', table_html=table_html)


# --- Dashboard & Static Pages ---
@app.route('/')
def dashboard():
    return render_template('dashboard.html')


@app.route('/accounts')
def accounts():
    return render_template('accounts.html')


@app.route('/settings')
def settings():
    return render_template('settings.html')


if __name__ == '__main__':
    app.run(debug=True)
